MD2wlx 1.00

Author:
Sergey Turko, tsi63@mail.ru

This listerplugin is a simple modelviewer (*.md2) for all game based on the Quake2 engine

Usage:
'A'	-> Move the model UP
'Z'	-> Move the model DOWN
'L'	-> Load texture (bmp, jpg, pcx, png, tga, tif)
'F1'	-> Help


Left Mouse	-> rotate
Right Mouse	-> menu (play, stop, load texture, help, about) 

-----------------------------------------------------------------------------

How to install this plugin (32 bit version only):

1. Unzip the md2wlx.wlx to the Lister directory (usually c:\wincmd\Lister or c:\totalcmd\Plugin)
2. In Total Commander choose Configuration - Options
3. Open the 'View/Edit' page
4. Click 'Configure internal viewer'
5. Click 'LS-plugins' button
6. Click 'Add' button and select the md2wlx.wlx
7. Click 'OK'

-----------------------------------------------------------------------------

License

MD2wcl is distributed as freeware.

