Blat Mailer plugin 1.2.9.0 for Total Commander
==============================================

 * License:
-----------

This software is released as freeware.


 * Disclaimer:
--------------

This software is provided "AS IS" without any warranty, either expressed or
implied, including, but not limited to, the implied warranties of
merchantability and fitness for a particular purpose. The author will not be
liable for any special, incidental, consequential or indirect damages due to
loss of data or any other reason.


 * Installation:
----------------

 1. Unzip the archive to an empty directory

For Total Commander:

 2. In Total Commander choose "Configuration => Options"
 3. Open the "Packer" page
 4. Click "Configure packer extension WCXs"
 5. Type "blat" as extension, alternatively you may type "mail" or "send_to"
 6. Click "New type" and select the "blat.wcx" file
 7. Click OK
 8. blat.ini is initialized after successfully closing the Blat Mailer
    configuration dialog for the first time.

For Send To:

 2. Place a shortcut (CTRL+SHIFT+F5) of blat.exe in directory
 	- C:\Windows\SendTo if you use Win9x,
 	- C:\Winnt\Profiles\%USERNAME%\SendTo if you use WinNT or
 	- C:\Documents and Settings\%USERNAME%\SendTo if you use Win2k or WinXP.


 * Installation Remarks:
------------------------

 o There is no need to use any other blat.exe from http://www.blat.net.
 o Utility blat.exe can be used with Open File shell for Total Commander, too.
   Recommended settings in OpenFileTC.ini are

    [Program0]
    Name=Blat
    FullPath=%COMMANDER_PATH%\Plugins\WCX\Blat\blat.exe
    HotKey=66


 * Update Remarks:
------------------

 o If you update from Blat Mailer 1.2.4.0 (and former) and if you saved
   the password to file blat.ini you need to retype the password in the
   configuration dialog due to fixed password encryption key.


 * Description:
---------------

Blat is a Public Domain Win32 utility to send mail via SMTP. To use Blat you
must have access to an SMTP server via TCP-IP.

Using the Blat Mailer plugin you can easily send mail with attachments. Before
sending an email you need to configure Blat by means of the configuration
dialog:
 o Recipient(s): recipient or comma separated list of of recipients
 o Subject: subject line (without quotes)
 o Message: message body text (only the first 2048 characters will be sent)
 o Sender: sender mail address
 o Server: SMTP server to be used
 o Port: port to be used on the SMTP server, defaults to SMTP (25)
 o Authentication: login with authentication
 o Use POP3 authentication: POP3 authentication before SMTP
 o Save authentication: save user and password to file blat.ini
 o User: username for server authentication (if applicable)
 o Password: password for server authentication (if applicable)
 o Log to file: log Blat output to file blat.log
 o Send attachments: attach all selected files to mail
 o Always show configuration: display configuration dialog before mailing


 * Limitations:
---------------

 o Blat must not be used to send unsolicited commercial email (UCE) or SPAM.
 o Only the first 8192 characters of the message body edit control will be
   saved to the message body text file (defaults to blat.txt).
 o Number of attached files is limited to 64.
 o Total file size of all attachments must not exceed 4GiB.
 o Number of stored recipients is limited to 99.
 o If option MessageFile contains %COMMANDER_PATH% environment variable
   blat.exe does not find the message body text file if started from Send To
   context menu.


 * Known Problems:
------------------

 o If you read an unxpected error 10053 from winsock in the log file (blat.log)
   and if you use McAfee VirusScan Enterprise 8.0.0 with firewall you should no
   longer block port 25 from sending. Go to the McAfee system tray -> Console ->
   Access Protection -> Port Blocking and uncheck port 25. It is labeled
   "Prevent mass mailing worms from sending email."


 * ChangeLog:
-------------

 o Version 1.2.9.0 (10.09.2006)
   - added Hungarian translation (Thanks to sduby.)
   - added known problems to Readme.txt (this file)
   - fixed: utility blat.exe does no longer need command line parameters of
     potential file attachments
   - fixed: if (after closing the configuration dialog) the message body text
     file (blat.txt) was read-only/locked a wrong message body was sent by mail
 o Version 1.2.8.1 (16.08.2006)
   - added Simplified Chinese translation (Thanks to Leo.)
   - fixed: changed dialog font from MS Sans Serif to MS Shell Dlg
   - fixed default text of Cancel button in progress dialog in utility blat.exe
   - fixed: import up to 99 addresses from address book of IrfanView Email plugin
 o Version 1.2.8.0 (15.08.2006)
   - fixed: password may contain blanks
   - fixed: show configuration dialog if blat.ini does not exist
 o Version 1.2.7.0 (10.08.2006)
   - added: utility blat.exe displays progress bar when sending files
   - added: About dialog displays blat.dll version information (if available)
   - fixed: user caused abortion of email transmission is logged to blat.log
 o Version 1.2.6.0 (12.07.2006)
   - added option IrfanViewIni to import address book of IrfanView Email plugin
   - fixed saving of recipients to blat.ini
 o Version 1.2.5.2 (03.07.2006)
   - fixed saving of recipients to blat.ini
 o Version 1.2.5.1 (01.07.2006)
   - fixed: option MessageFile supports %COMMANDER_PATH% environment variable
 o Version 1.2.5.0 (26.05.2006)
   - fixed: option MessageFile supports %COMMANDER_PATH% environment variable
 o Version 1.2.4.1 (26.05.2006)
   - fixed: former password encryption key did not work for all passwords
   - fixed: allow POP3 authentication before SMTP
 o Version 1.2.4.0 (17.05.2006)
   - fixed codepage of Russian translation (Thanks to Nick and Sergey.)
   - fixed: allow POP3 authentication before SMTP
   - recompiled Blat library 2.5.0 with INCLUDE_POP3
 o Version 1.2.3.0 (15.05.2006)
   - added blat.exe to be used with Send To context menu
 o Version 1.2.2.0 (08.05.2006)
   - added Polish translation (Thanks to djk.)
   - added Russian translation (Thanks to Sergey.)
   - added Spanish translation (Thanks to Sombra.)
   - added option SaveAuthentication to toggle user and password storage
   - added Language selection dialog
 o Version 1.2.1.0 (04.05.2006)
   - added Dutch translation (Thanks to RolandD.)
   - added French translation (Thanks to Ouistiti.)
   - fixed: only refresh progress bar when sending attachments
     (AttachFiles = 1)
   - fixed: changed dialog font from MS Sans Serif to MS Shell Dlg
 o Version 1.2.0.0 (03.05.2006)
   - added option Language for internationalization, defaults to English
   - added language file blat.lng
   - fixed: Blat library displays progress bar when sending files
   - fixed user abortion when sending files
 o Version 1.1.2.0 (28.04.2006)
   - fixed memory allocation / deallocation in PackFiles
   - fixed: Blat library correctly displays progress bar when attaching files
   - recompiled Blat library 2.5.0 with BASE_SMTP_ONLY
   - added option AttachFiles to toggle sending attachments
   - added option AlwaysShowConfiguration
   - added: save list of most recently used recipients (up to 20) in section
     [Blat Mailer Recipients] of blat.ini
 o Version 1.1.1.0 (26.04.2006)
   - fixed: corrected spelling of authentication
 o Version 1.1.0.0 (26.04.2006)
   - added option LogBlat to log Blat output
   - added option MessageFile for message body text file
   - added: all options are stored in section [Blat Mailer Settings] of
     blat.ini
   - fixed: added PK_CAPS_OPTIONS to GetPackerCaps
   - fixed Blat command line if authentication is required
   - replaced Blat library 2.2.2 by latest official Blat library 2.5.0
 o Version 1.0.1.0 (23.04.2006)
   - fixed memory deallocation in PackFiles
   - moved About dialog to packer configuration dialog (ConfigurePacker)
   - replaced Blat library 1.9.4 by official Blat library 2.2.2
   - fixed typo in Descript.ion
 o Version 1.0.0.1 (22.04.2006)
   - first public version


 * References:
--------------

 o Blat by Pedro Mendes, Mark Neal, Gilles Vollant, Tim Charron, Tim Musson,
   Harri Pesonen, Arthur Donchey & Chip Hyde
   - http://www.blat.net
   - http://groups.yahoo.com/group/blat
 o WCX Writer's Reference by Christian Ghisler & Jiri Barton
   - http://ghisler.fileburst.com/plugins/wcx_ref2.1.zip


 * Trademark and Copyright Statements:
--------------------------------------

 o Total Commander is Copyright � 1993-2006 by Christian Ghisler, C. Ghisler & Co.
   - http://www.ghisler.com
 o UPX - The Ultimate Packer for eXecutables is Copyright � 1996-2006 by Markus
   Oberhumer, Laszlo Molnar & John Reiser
   - http://upx.sourceforge.net


 * Feedback:
------------

If you have problems, questions, suggestions please contact Thomas Beutlich.
 o Email: support@tbeu.de
 o URL: http://tbeu.totalcmd.net