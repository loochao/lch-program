Control Panel 1.0 - plugin for Total Commander 5.5 and newer
____________________________________________________________________________
These software are provided "as-is". No warranty provided.

You use this program at your own risk. The author will not response for 
data loss, damages, etc. while using or misusing this software. 

This plugin is freeware.

----------------------------------------------------------------------------
To install plugin, proceed as follows:
 1. Unzip the archive to an empty directory
 2. Choose Configuration->Options->Operation->FS-Pugins
 3. Click "Add"
 4. Go to the directory where you unzip the archive and choose cpl.wfx
 5. Click OK. 
You can now access the plugin in "Network Neighborhood" as "Control Panel"

----------------------------------------------------------------------------
Features:

  - Allow browsing Control Panel applets from TC panel
    and executing by pressing "Enter" key (mouse click).
  - Show some info about each applet by pressing "F3" key.
  - Fast access to descriptions in "Descript.ion" file.

Tested under XP.

Version history:
---------------------
v 1.0 - 24.11.2002
  - Initial version

----------------------------------------------------------------------------
Author:
  Sergey Kostyuk, Lugansk, Ukraine
  mailto:k_ser@ukr.net
