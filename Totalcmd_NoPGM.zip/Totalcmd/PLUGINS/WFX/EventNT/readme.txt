Events NT 1.4RC1 - plugin for Total Commander 5.50, 5.51 and newer
____________________________________________________________________________
These software are provided "as-is". No warranty provided.

You use this program at your own risk. The author will not response for 
data loss, damages, etc. while using or misusing this software. 

This plugin is freeware.
----------------------------------------------------------------------------
To install plugin, proceed as follows:
 1. Unzip the archive to an empty directory
 2. Choose Configuration->Options->Operation->FS-Pugins
 3. Click "Add"
 4. Go to the directory where you unzip the archive and choose EventNT.wfx
 5. Click OK. 
You can now access the plugin in "Network Neighborhood" as "NT Events"
----------------------------------------------------------------------------
Features:

Total Commander 5.50:
  - Allow browse NT Events from TC panel
  - Works only under NT platforms  (NT/2000/XP)
  - Allow clear the Event Log
  - Dialog box with information (press Enter key)

Total Commander 5.51 or later:
  - Show icons according the Event Type
  

Tested under Windows 2000,XP.
----------------------------------------------------------------------------
Author:
  Sergey Kostyuk, Lugansk (Ukraine)
  mailto:k_ser@ukr.net
