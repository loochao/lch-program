About Total Resizer
Total Resizer (TotalRSZ) is a Packer/unpacker plugin for TotalCommander (TC). It's function 
is to resize image files in batch mode. 

Installation:
Unzip TotalRSZ.zip, put the files in the folder where TC sits or anywhere you like. 
Run TC, from the menu:
	Configuration-->Options...-->Packer
	click "Configure packer extension WCXs",
	then enter "rsz" without quotes in the field of 
	"All files with extension (ending with)". Then click "New type" button, 
	select "TotalRSZ.wcx". Click "OK". That's all of it.


Usuage:
In TC, select one or more image files, then press "Alt+F5". From the opened dialog, 
choose rsz as the external packer. Click OK, and in the opened TotalRSZ dialog, set 
the appropriate parameters, then click OK. TotalRSZ will resize the image files using 
the parameters. The destination path is the one displayed in another pane of TC.

TotalRSZ can also operate on folders. If you select the folders, TotalRSZ will try to 
resize image files in all the sub-directories.


Notes:
1. About the target file name. $(FileNameNoExt) is automatically filled in the text 
field, which stands for the source file's name. You can add any prefix or suffix to 
it, for example, AAA$(FileNameNoExt)BBB. But $(FileNameNoExt) must be a part of the 
name.

2. About the target image format. There are two options. The first one is the same 
as the source file. For example, if the source file is a jpeg, then the target is 
also a jpeg file. The second option is to choose a specific format for all the target 
files. If you select multiple files to resize, then using the second option, the target 
files will be in the same format.

3. About the target image size. There are two options as well. The first one is to 
set a specific size. The second is to set a value of percentage. No mater which 
option is used, the aspect ratio of the image is unchanged. For example, set the 
target image of size 500x400, the aspect ratio is 5/4. Using the first option, if the 
source image's aspect ratio is also 5/4, then the source image will be 
scaled to the desired size. If the specified aspect ratio is not the same as the 
source, then the actual target image's size is determined in such a way that using 
one of the specified sides and the source aspect ratio, the calculated the other 
side is not greater than the specified value. For example, using the same values for 
the target image as the previous example, if the source aspect ratio is 1:1, then the 
target image size will be 400x400; if the source aspect ratio is 5:3, then the actual 
target image size will be 500x300; if the source aspect ratio is 3:4, then the actual 
target image size will be 300x400.


License:
Copyright (C) 2004 W. Dong, taohe@hotmail.com
License to copy, use, and redistribute this software for any purpose is granted 
provided that this notice may not be removed from this document. 

This software is provided 'as-is', without any express or implied warranty. 
In no event will the authors be held liable for any damages arising from the 
use of this software. 


Credits:
TotalRSZ is based on ImageMagick. 
ImageMagick is copyright ImageMagick Studio LLC. 
For the license of ImageMagick, please read imagemagick_license.txt��