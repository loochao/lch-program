Abstract

Note: the PDF Filter plugin was renamed to Multi-Lister as this reflects the purpose of the plugin.
This readme will breakdown the format and parameters of INI -file as well as the
filter's log file (filter.log).
Information contained herewith is applied to version 1.05.051 (11 July, 2006).
For description of what the Plugin is please refer to listfilter.txt
file.
I do not suggest to adjust all these values manually, for there is a special tool
developed for that purpose, the configuration utility.

1. Initial initialization and preparation for configuration file reading
(listfilter.ini) (IMPORTANT!)

As it follows from the plugin nature, the Plugin uses its own configuration
file for settings.
Upon initialization the Plugin (hereinafter referred to as "filter")queries
the TC's lsplugin.ini file first.
(for TC version 5.51 and higher.) . Thus, if the file lsplugin.ini exists and
contains [PDFFilter] (obsolete) or [MultiLister] sections, the plugin reads the IniDir parameter if any.
NOTE: The section [MultiLister] has the priority over the [PDFFilter] if both are available in the INI file.
The IniDir parameter may be equal to %TC% (case insensitive) - this value is for
those individuals who want to have all the INI files in one place (this is not
applied to me :) ), and tells the plugin that listfilter.ini is situated in the
same folder as lsplugin.ini. If this value is empty or not present, then the
plugin will get the listfilter.ini from its own folder (for my configuration, it
is located in Wincmd\Plugins\Lister\PDFFilter folder), and, at last, for those
who wish to have listfilter.ini in an arbitrary folder on disk (I don't know
anyone though :) but...), it is possible to set PDFFilter entry to point to a
folder where the listfilter.ini
will be read from. Personally, I would recommend not to create [PDFFilter]/[MultiLister] section of
the lsplugin.ini file at all, as I do :), however, it's entirely up to you :) .
The listfitler.ini is just a usual configuration file with the same syntax as
any INI-file.
Comments are to be placed onto a separate line, and should be prepended with ";"
(no quotes).

2. Plugin operation concept

The plugin receives a filename to be viewed from TC. It then searches the
listfilter.ini for availability of the section named as the file extension.
Thus, the section [PDF] should be present for files with .PDF extension, the
section [ABC] should be present if the plugin is also capable of viewing files
with ABC extension, etc.
The Plugin can process an arbitrary file provided there is a
converter (converters) capable to convert the file into BMP/GIF/JPG, TXT/RTF, or
HTML.
The MSHTML object can be used for viewing of any supported files by the plugin if necessary.
Of course, this will require an appropriate ActiveX to be available and to be loaded by MS Internet
Explorer core,  and might consume vast amount of memory (about 50M for Adobe Reader for example).

OK, let's get back to the subject at hand. So, if the section with name matched
to the file extension is found in  listfilter.ini file, the plugin reads that
section. Now, come to details of the section structure.

1. The "StartFile" parameter tells the plugin that the file to be viewed MUST
start with certain characters. Wild cards (*) are OK. Below is an example of the
[PDF] section with StartFile parameter.
NOTE: Since MultiLister ver. 1.2 the section may can contain multiple extensions separated by pipe ("|"),
e.g.
[EXT1|EXT2|EXT3|...|EXTN]
if one converter is able to process many extensions, it is recommended to place that converter into
[COMMONCONV] section (see below).

[PDF]
StartFile=%PDF-*
This tells the plugin that any file with PDF extension must be started with
%PDF-, then any symbols. If the file to be viewed with the PDF extension is not
started with this string, the plugin immediately returns control to TC with
"message" "I do not read such files". The TC will automatically call the next
plugin, and if it fails, will show the standard Lister window with raw text.
Since filter version 1.03.1 the %hex% specifier is supported  - it tells the
plugin that the sequence following the %hex% should be considered as hexadecimal
numbers It is allowed to have as many %hex% specifiers in the StartFile
parameter as necessary.
IMPORTANT!: The hexadecimal sequence MUST be ended up with SPACE (it indicates
the end of this hex. sequence for plugin, and the space itself will be cut off
by the plugin).
Example: StartFile=%hex%CAFEBABE *. More advanced: StartFile=%hex%010203
BEST%hex%0C0A *

2. The "HeaderSize=N" Parameter tells the plugin to read N bytes from the file
begin for future identification. Headersize is 512 by default, however, there
was one PDF file, where I got the situation the Pagecount was indicated from
byte 1000, therefore, I set this value for PDF-file to 1024 in listfiler.ini.
Honestly, that was the only file where /N (the number of pages) was beyond the
512 bytes boundary.

3. The "PageCount=/N %pdffilter_num%" parameter tells the plugin that to get the
number of pages in the file, it is necessary to find the string after PageCount=
not considering the %pdffilter_num%, where the number of pages will be placed
afterwards., this is necessary to properly indicate and consider the number of
pages (Page N of NN), which is displayed in the upper right corner of the
plugin's toolbar.

4. The "Default" Parameter informs the plugin, which filter number will be the
default one for the extension. The first one is selected if this parameter is
omitted. The numeration is started from "0" (no quotes). It is recommended to
set Default from within the plugin ("Set as Default" feature of the context
menu).

5. "Fitpage" - this parameter tells the plugin the way of fitting an IMAGE into
the page, NOT recommended to change it manually. Everything is perfectly set
from within the plugin (Picture->Fit to page width/height/page).

6."Scale_N=NN" informs the plugin regarding the scale to be used when displaying
an IMAGE by the appropriate filter N.
This value is set by plugin automatically in IMAGE mode and changing of the
scale, though nobody prohibits to change this value manually - do you really
need this? :).

7. "Resolution" - informs the plugin to replace %res% placeholder for Format
line (see below) if the filter supports it, by this value.(see. %res%
placeholder below)

7. Format lines. This is actually a heart of the section.
The format line tells the plugin, which filter to be used, and with which
parameters..

IMPORTANT! Each format line is started with "Format_" (no quotes).

Each format line has the following format (optional parameters are embraced with
[]):
Format_TYPE=Application_filter<TAB>parameters, placeholders and
modifiers[<TAB>Description]
TYPE - the type of the filter: TXT - if the filter creates a text file (includes
RTF), HTML - no need to comment :), ACTIVEX - see below; all the rest extensions are considered 
as "pictures" (plugin supports BMP,GIF,JPG,WMF).

IMPORTANT! I would like to stress attention of those using text editors
replacing TAB characters with SPACES.:
       In case you have "Replace tab chars with spaces" option within your
editor and editing of the listfilter.ini file
       you will get inoperative format line (noted by SCOOTER), which result in
calling of the
       Adobe Acrobat ActiveX (if installed) when viewing PDFs, or to displaying
the file by Lister AS IS (that is, in raw mode) unless there is a plugin
(plugins) capable to show those files.
       Actions required:: switch that feature off for editing of the
listfilter.ini file
       and bring the format lines into the format specified above.
       
ACTIVEX type:
------------
This is a special format type. It looks like:
Format_ACTIVEX={GUID1},{GUID2}...{GUIDN-1},{GUIDN}
Where GUID1..GUIDN are GUID identifiers used to check whether the plugin should invoke the
MSHTML to render the file contents.
NB: The plugin DOES NOT use the controls. Instead, the MSHTML is invoked to render the file.
The GUIDs purpose here is just to let the plugin to check for GUIDs availability and if not available,
disable rendering (for this would cause "Save the file to.." MSHTML dialog to appear).
It is highly recommended to use the filter_cfg.exe (Filter Configuration Utility) mentioned above to
insert the GUIDs unless you are a Windows GUID's Wizard.


MODIFIERS and PLACEHOLDERS.
------------------------------------

PLACEHOLDER - is a place, which will be replaced with the data corresponding to the placeholder's tag;
modifier - a command to the plugin, and will be removed by the latest from the
filter command line prior starting of the converter application.
All placeholders and modifiers are prepended and are ended up with "%" (no
quotes).
All the placeholders and modifiers ARE CASE SENSITIVE

The plugin "understands" the following placeholders:
%fn% - Full short path and short filename to the file to be viewed. I do
recommend to use indeed this parameter, because, for some reason, a majority of
converters do not understand the long filenames. By the way, I found that
pdf2bmp converter shipped with Abbyy FineReader did not understand folders/files
containing non-English characters (e.g. cyrillic).
%Fn% - same as above, but for long filenames. I don't use this placeholder and
neither advise that to you. (see above), unless absolutely necessary.
%p1%-will be replaced with the number of the first page to be processed
%p2%-will be replaced with the number of the last page to be processed
Moreover, those two placeholders tell the plugin that the filter supports
page-by-page output, which speeds up the process a lot, so that the plugin asks
filter to process all-pages-at-one-go only when searching for text.
%o% - The plugin will place the temporary output filename into this placeholder.
Might be omitted for applications which produce console output only (see stdout
modifier below).
%res% - will be substituted with Resolution parameter value (see above).
%tc% -  will be substituted with TC's directory (e.g. C:\Program Files\Wincmd\),
    including the backslash ("\"). Suggested by Dmitry.
%tcc% - will be substituted with TC's config folder.
        (especially useful if TC is installed on a U3 device)
%odir% - will be substituted with the output directory path


The following MODIFIERS can be used in a Format line:
-------------------------------------------------------
%stdout% - tells the plugin that the converter produces output to stdout, that
is, on screen (e.g. ps2text), and that the plugin must capture the stdout and
use it.

%hide% - probably, a rudiment, though, maybe, there will be "individuals" as a
friend of mine, which cannot live without that black command line window when
filter is working. Ommitting %hide% tells the plugin to start the application and
to show its output in the Command line (DOS) window. Honestly: I don't use this feature.

%console% - This is what can be widely used. This modifier tells the plugin that
it should start the application-converter  and capture output. This is something
like stdout except the data captured are displayed in a separate sub-window.
This modifier, of course, should be used with %hide%. Using this modifier, the
window is divided by two parts: the converted page is displayed in a larger one,
and the lower one simulates Command line output informing regarding the
conversion process. Personally, I used this parameter for debugging format
lines. However, this parameter can be useful if the filter takes long time to
convert page(s), or write something into stdout. At least, one may be sure
nothing is hung.:)

%highpriority% - tells the plugin that the filter being started should have high priority.
This could rarely be useful.

%hour% - this modifier means a converter will have 1 hour timeout to finish processing
of the file (default is 1 minute). A user can cancel this lengthy process at any time.
Of course, it is possible to set DefaultTimeout to 3600 secs etc., but this modifier applies
to the only converter, whereas DefaultTimeout applies for all converters.

%--% - This modifier tells the plugin, that the page enumeration is started with "0", and not
       with "1",(by the way, this is behavior of Pdf2Bmp, shipped with Abbyy FineReader :) )

%fp%,%lp% - these modifiers tells the plugin that are followed by switches for
first and last pages respectively. This parameter is required to omit page
numbers transfer to converter when converting of the whole document (sometimes,
it is not possible to recognize the number of pages-I do not write a PDF-reader anyway, huh?
:), therefore the number of pages will be properly specified only for linearized
PDF documents, which are about 70% of all the rest. In other cases ???
characters will be displayed instead of the Page Count. If you know a universal way to get the
number of pages out of the PDF, not using any additional libraries, please let me know.

%i% modifier tells the plugin that this particular converter does not recognize output
parameters (like output files etc.), thus such a converter produces
a file within the current directory. For example, this behavior is common for FLARE
(SWF->SWF Action Scripts converter). Introduced with version 1.05.051.


Besides placeholders and modifiers mentioned, the plugin supports one more
(actually 2) let�s call them SPECIFIERS, for they are both placeholders and
modifiers.
--------------------------------------------------------

%e%, followed by output file extension - tells the plugin to tear the default
extension and use the extension specified after "%e%.
IMPORTANT: when used, this parameter must be the last one;
%e% IMMEDIATELY followed by file extension. Thus, %e%html->file.html, and %e%
html->file. html, which is not the same and will cause an error "Converted file
could not be found".


Bunch %n%Num is probably the most tangled specifier. It was introduced to view
multi-paged PS documents. This is caused by gswin32c "feature" to convert only
the first page of the PS document regardless request of page 2. 3 etc.
Fortunately, GS developers (and not only GS, by the way) stipulated a so called
BATCH processing when file name/extension parameters are given by user .In this
case all the converted pages are placed into disk in accordance with mask.
%n% ALWAYS works with %o% (see listfilter.ini, section PS).
Specifier format is as following: %n%NM, where N-is a number of meaningful chars
(from 1 to 9, thus theoretically up to 999999999 are allowed with names
ps_000000001.bmp,...ps_999999999.bmp), and M-is a mask/modifier, which is
understood by converter (e.g., %03d for gswin32c).
Example: %n%3%03d - 3 digits will be substituted for page number within the
filename with leading zeroes if necessary.

Description  is an optional parameter, it contains filter description, the way
it will be shown in "View mode" menu for the appropriate converter (Text, Image,
or HTML).

Example:
Format_TXT=C:\XPDF\pdftotext.exe    %fp%-f %p1% %lp%-l %p2% -enc KOI8-R
-layout %fn% %o% %hide%%console%    pdftotext-KOI8
Example's description:
a. Filter C:\XPDF\pdftotext.exe returns Text or RTF file, thus, text search can
be organized with that filter.
b. Filter supports by-page output, thus probably operates pretty fast.
c. The short filename is passed to the converted in 8.3 format (DOS format)
d. The black window of the Command line is not shown (%hide%)
e. The output is captured and information is shown in the lower sub-window
f. Text filter menu displays this converter as "pdftotext-KOI"

Since version 1.2 The MultiFilter supports "ierarchical" (or stage-by-stage) conversion via the
following mechanism.
Let's say that we need to view a file with extension DONTKNOW. The filter knows how to deal with
extension IKNOWIT, and that KNOWIT's converter produces HTML output. Then:

[DONTKNOW]
Format_KNOWIT=knowit.exe[TAB]params
...
[KNOWIT]
Format_HTML=knowitHTML.exe[TAB]params...

In this case the plugin will invoke the converter to convert the file into one format and if this process has been completed successfuly, it would invoke second converter to convert in another format etc.

Using of the common converters (introduced in the MultiLister v. 1.2).

There are several converters which are capable to handle many types of files. Instead of listing those under
the extensions sections, it is possible to tell the Plugin to apply common converters for the files.
The format of the Common Converters section ([COMMONCONV]) is different from the files sections mentioned above.

There are no specific parameters to be present in the Common Converters section. Instead, the section looks like

[COMMONCONV]
Format_TYPE1=Application1|EXT1|EXT2|..|EXTN-1|EXTN<TAB>parameters1<TAB>Description1
...
Format_TYPEN=ApplicationN|EXT1|EXT2|..|ExtN-1|EXTN<TAB>parametersN<TAB>DescriptionN

where TYPEN could be any of the supported formats including an extension for stage processing.

Common Converter can also be assigned as a default converter for any file type.
----------------------------------------------------------------------------------------------

Note1: The plugin can search for text ONLY if at least one filter TXT or HTML is
specified for the given file extension.
Otherwise, the plugin will report on search unavailability.

Note2: The plugin tries to use the default filter/converter (or the first
available if no Default is specified).
If it fails then the next converter of the same type is used .etc. If none of
the same type filters succeeded the plugin utilizes all the other filters until
success. If none of them succeeded, and ActiveX feature is not disabled and ActiveX is specified within the appropriate section of the .ini file,  the plugin tries to invoke the ActiveX(if available) to view the file.

Note3: If a converter converts the files and the converted version is empty, the plugin
will invoke the next available converter for this type of file and for this type
(e.g. TXT) UNLESS that converter SUPPORTS page-by-page conversion. In that case you should
manually select a different converter from the list of available converters for that
type of file. This behavior can be enabled/disabled by setting the following key in
[General] section (see below).

OK, and last, but not the least :) section of the INI file listfilter.ini is the
section
[General], where the following parameters are allowed:
Logging - tells the plugin to maintain operation log (filter.log): 1=yes, 0=no.
By default:0.
If everything is working OK, set to 0.
LoadPageOnUpDownClick -  if not 0, tells the plugin to convert next/previous
pages if up/down arrow button is clicked (thanks to SUKER for an idea)
TextViewerFont - This parameter holds a user-defined font for text/rtf view. The
font can be changed from the View Mode->Use conversion->RTF/Text->Set font menu.
ReverseUpDown - if not 0, tells the plugin to change behavior when clicking
up/down arrows of
the Page selector. Thus clicking the down arrow will result in next page display
etc. This parameter is introduced for those using the LoadPageOnUpDownClick
(like I do).
CopyFileToTempBeforeConvert = N - tells plugin to copy file to be viewed with
file size up to N Megabytes to a temporary folder, and rename it there to
target.EXTENSION, prior invoking a converter. This is implemented for those
converters which do not work with file/folder names containing non-English
characters, (e.g. converter pdf2Bmp does not work with such files). The plugin
copies the temporary file into temporary folder. That is why it is important the
temporary folder should not contain non-English characters.
ShowInProgressOnFirstOpen - this parameter (0 or 1) tells the plugin to force showing the 
Lister window on initial opening of the file being viewed. The Lister's window caption is
changed to "..conversion is in progress" while the initial conversion is being performed. 
Default is 0.
OutputDebugString = (0 or 1, default is 0) - tells plugin to use OutputDebugString for
debugging. The output might be intercepted e.g. by Sysinternals' Debug monitor (DBGVIEW), 
http://www.sysinternals.com
DisablePDFActiveX - this option tells the plugin to not to try loading the PDF ActiveX if 
required. If no converters are available for PDF, plugin will immediately return control to
the Lister.
DefaultTimeout - is a timeout for converter to finish conversion. If a filter was not able to
finish processing for this amount of time, or "hung", the plugin would terminate the converter.
ConsoleOnAlways - tells plugin that if the file size of a file to be processed by a converter, is 
greater that NN Kb, the plugin should display the console window to track output by a user. This
value is usually set to "disabled".
SwitchToNextConvOnEmptyDocIfAvail - if set to 1, the plugin will invoke another converter for the
same file if the currently used converter returned just an empty file, UNLESS the converter SUPPORTS
page-by-page conversion.
HTMLMatchColors - set of colors used for background and foreground of text matching search parameters
when searching within HTML/IE Mode (if available). The format is bgcolor1:fgcolor1,bgcolor2:fgcolor2,...,
bgcolorN:fgcolorN. By default:
HTMLMatchColors=yellow:red,blue:white,red:white,green:white,brown:white

SEARCHING FOR TEXT WITHIN FILES
Since version 1.04, the plugin is capable to search text not only within the
file being viewed, but also in files/folders
on disk. I had to realize this feature when I had to search for text within 1200
PDF files and 250 PS. First, I tried to search using software I was searching
for in the Internet, but none satisfied me. So, this feature came into the
plugin.
So, that "extra" 7K of filter.wlx are responsible for search interface.
The search string for searching within the files has its own format:

The search string format is as following (optional parameters are embraced with
[]):
[Mask[/r]|]"Text to search for"
Where: Mask is a mask of files to be searched for, which is usual DOS/Windows
file mask, e.g., *.pdf or C:\*.pdf, or D:\MyDir\*.* etc.;
/r modifier when using file mask means "Recursive", that is the plugin will
search not only the folder specified, but all the subfolders as well. It is
allowed to use "relative" paths (e.g. ..\text). In this case the plugin will
consider the folder containing the file being viewed in Lister as the current
folder. It is allowed to use just
/r|"Text". This tells the plugin; "Search files with the same extensions as the
current one in all subfolders of the current folder." The current extension is
a file extension of the file being browsed in this Lister window with the
plugin.
The file mask MUST be ended up with "|" (no quotes)
"Text" can contain any characters, the only requirement is that it MUST be
"embraced" with quotes ("), for example:
""papa||d|etc.""". Sometimes it is required to search all files with the current
extension within the current folder, and not in subfolders (that is search files
within the current folder only). In this case it is allowed to omit the
file mask, and the search string will look like "Text".

IMPORTANT!: The string to be searched for (NOT THE MASK!)MUST BE "EMBRACED" WITH
QUOTES (").

Since version 1.05 the above mentioned "shamanism" is no longer required. (though it is tolerated anyway).
There is a button in the plugin's toolbar clicking which the search dialog pops up
Everything is clear there.

Steps to perform the file search:
1. Enter the View mode indication field (this field is editable) next to the
right from the "View Mode" button.
Type in the search string according to the format above. Press "ENTER" when
finished
2. In case the search string typed failed to comply the search string format
(see above), a message is displayed, and the search operation is performed
within the page. Otherwise see item 3 below
3. Plugin first disables typing in the input field (see above) and disables
by-page page switching until search is finished. Search for text within the
by-page display mode will not work as well during file search.
4. Output window will display the path and the name of the last processed file.
5. Files matching the mask, are processed and are transferred to the appropriate
converter/filter, then, on success, the files are searched by the plugin for
string to be searched for, and, if match is found, the filename is appended to
the Search results window.
To switch between Output/Search results windows the context menu (right mouse
click) is used.
The Output/Search panel is turned on/off via the hotkey "O" (no quotes).
To force the plugin to stop the file search the "ESC" key is used.
6. Having finished the file search, the Result window will contain the list of
files matched the criteria. To go to the file part containing the search string,
is accomplished by double clicking of the appropriate file name in the Search
Results window. The file being viewed is marked with bold in the Search results
window.
7. Search results can be saved to work with them further. This is done via
Search Result window context menu.
8.To load search results the same context menu is used, "Load..." menu item.

--------------------------------------------------------------------------------
--------------------------------------
Plugin's log file.

In case of any deviations/malfunctions the log file is helpful.
As it was stated above, the plugins writes log file filter.log Logging entry is
set to 1 in the listfilter.ini file.
Also, plugin logs all its operations via OutputDebugString regardless of whether
the Logging is set or no.
Two examples of log file activities (my comments are prepended with !):

!1. A user which did not setup listfilter.ini settings properly.

!Invoking plugin to view the file
11.03.2004 13:08:27 ================= 11.03.2004 13:08:27 Invoked.
==============
!Getting extension
11.03.2004 13:08:27 extension: .pdf
!Reading section and analyzing
11.03.2004 13:08:27 Got 17 entries for this extension
!Preparation
11.03.2004 13:08:27 Ready to create form
11.03.2004 13:08:27 Formcreate invoked
11.03.2004 13:08:27 Form created
!Querying if Adobe Acrobat (Reader) is installed
11.03.2004 13:08:27 Inserting PDF ActiveX...
!Not installed - continue
11.03.2004 13:08:27 Unable to create ActiveX PDF control: Class is not
registered
!Searching for filter(s)
11.03.2004 13:08:27 ListerView instance created
!Skipping comments and empty lines
11.03.2004 13:08:27 Empty line or comment ;Format_TXT=c:\Program
Files\SolidDocuments\SolidConverterPDF\SolidConverterPDF.exe /i %fn% /o %o% /y
/t rtf %fp%/p %p1%-%p2% is being skipped
11.03.2004 13:08:27 Empty line (see above) skipped
!Here it is - now the internal plugin procedure will analyze filters'
availability and return the number of filter to be used.
!If it returns -1 - then this means no filter(s) found, and it will try to
invoke Adobe Acrobat ActiveX.
11.03.2004 13:08:27 number after CheckSearch proc: -1
!The procedure displaying the content is invoked, but it will immediately return
control to TC (Acrobat is not installed) indicating "Can't view the file!"
11.03.2004 13:08:27 Displ proc is to be invoked
!That's all! The user gets raw PDF within the Lister, AS IS, with non-printable
characters if any.
================================================================================
====
!2. A user which has properly setup the listfilter.ini settings.

!Invoking plugin to view the file
12.03.2004   10:24:47   ================= 12.03.2004 10:24:47 Invoked.
==============
!Getting extension and reading the section
12.03.2004   10:24:47   extension: .pdf
12.03.2004   10:24:47   Got 18 entries for this extension
12.03.2004   10:24:47   Ready to create form
12.03.2004   10:24:47   Formcreate invoked
12.03.2004   10:24:47   Form created
!Querying for availability of the Acrobat ActiveX
12.03.2004   10:24:47   Inserting PDF ActiveX...
!Not installed. Continue
12.03.2004   10:24:47   Unable to create ActiveX PDF control: Class is not
registered
!Search for filter and parsing section
12.03.2004   10:24:48   ListerView instance created
12.03.2004   10:24:48   Empty line or comment ;Format_TXT=c:\Program
Files\SolidDocuments\SolidConverterPDF\SolidConverterPDF.exe   /i %fn% /o %o% /y
/t rtf %fp%/p %p1%-%p2% is being skipped
12.03.2004   10:24:48   Empty line (see above) skipped
!Found default converter. Application exists.
12.03.2004   10:24:48   Found "Default" entry, value=1
!Invoke CheckSearch to get the number of converter to be used
12.03.2004   10:24:48   number after CheckSearch proc: 1
!Ready to invoke converter #1
12.03.2004   10:24:48   Displ proc is to be invoked
!Output directory creation
12.03.2004   10:24:48   Verifying OPDir
!Transforming the Command Line
12.03.2004   10:24:48   CurrentFmt is C:\XPDF\pdftotextKOI.exe   %fp%-f %p1%
%lp%-l %p2% -enc KOI8-R -layout D:\deb.pdf C:\TEMP\_tcf_\1202448\pdf_%page%.rtf
12.03.2004   10:24:48   Ready to execute
!The line is transformed and the plugin is ready to invoke application to
execute
12.03.2004   10:24:48   File execution. Command line and params:
C:\XPDF\pdftotextKOI.exe -f 1 -l 1 -enc KOI8-R -layout D:\deb.pdf
C:\TEMP\_tcf_\1202448\pdf_1.rtf
!The format line contained %console% or %stdout% modifier(s). Ready to capture
the output
12.03.2004   10:24:48   Activating piping
!Operation finished successfully. The Lister window is being transformed in
accordance with the TYPE (TXT)
12.03.2004   10:24:48   Setting TXT panel (RichEdit)
!User lists the file (page-up.down). Current page - 1, next - 2
!See above.
12.03.2004   10:24:55   ShowPage invoked. CurPage=1
12.03.2004   10:24:55   Found "Default" entry, value=1
12.03.2004   10:24:55   number after CheckSearch proc: 1
12.03.2004   10:24:55   Displ proc is to be invoked
12.03.2004   10:24:55   Verifying OPDir
12.03.2004   10:24:55   Ready to execute
12.03.2004   10:24:55   File execution. Command line and params:
C:\XPDF\pdftotextKOI.exe -f 2 -l 2 -enc KOI8-R -layout D:\deb.pdf
C:\TEMP\_tcf_\1202448\pdf_2.rtf
12.03.2004   10:24:55   Activating piping
12.03.2004   10:24:55   Setting TXT panel (RichEdit)

OK, now I hope everything became clear and simple.

Vladimir Olovyannikov,
e-mail:
volovyan@gmail.com