TotalCommander Lister Plugin nfoviewer 0.8 by MovieZ (MovieZ+nfo@gmail.com)

History & features:
 v0.8
   + Support Thumbnail view in TC 6.5
   + Select and copy a word when doubleclicking it
   + small changes
 v0.7.1
   + Add missing horizontal scroll
   + Add 4 Option:Auto adjust window width when changing font size; Center view; Remember window size and position
 v0.7
   + Custom font size
   + Support *.diz
   + Press Enter to maximize window
   * Fixed: a fatal Bug 
 v0.6.1
   * Fixed: a hyperlink autodetection bug
 v0.6
   + Block select option
   + Http hyperlinks autodetection
   + Custom color
   * Small change and corrections
 v0.5
   + Save as picture (png file, Ctrl+S)
   + Smart Paste serial number like "x-x-x" or "x x x"(Ctrl+Alt+V, keep Lister window open when paste)
   + Copy Filter option (replace all char(>127) with space)
   * Fixed: a scroll bug in win9x
 v0.4
   + Center View
   + Select All(Ctrl+A)
   + Small change and corrections
 v0.3.1
   Initial public release
   Copy-on-Select

Bug Report:
Any bug reports or suggestions are welcome, please send it to MovieZ+nfo@gmail.com.