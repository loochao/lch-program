Author:
Jonas B�hr [de/en/fr], jonas.baehr@web.de

This listerplugin is a simple modelviewer (*.mdl) for all game based on the Half-Life engine (such as Conterstrike, Day of Defeat, etc.)
It is based on the Half-Life SDK
Some of the sourcefiles are (C) by Valve-Software

Usage:
'+'	-> Next Animation
'-'	-> Prev Animation
's'	-> Stop (freeze) the Animation (press again to unfreeze)
'a'	-> Advance 100ms in current animation (only while stopped)
'A'	-> Rewind 100ms in current animation (only while stopped)
'r'	-> Cyrcle Rendermodes (Wireframe, Flatshaded, Smoothshaded, Textured)


Left Mouse	-> rotate
	+ Ctrl	-> move
	+ Shift	-> zoom
