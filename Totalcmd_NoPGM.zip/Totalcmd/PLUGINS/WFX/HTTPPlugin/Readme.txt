HTTP SmartBrowserPlugin 1.1 for Total Commander
===============================================
http://www.acd-group.com/Softwaredevelopment/HTTPPlugin

   Welcome to the HTTP SmartBrowserPlugin 1.1 for Total Commander - the new way
   of managing http downloads with Total Commander!

   What's new in Version 1.1?
   ==========================
    * Website cache for faster and offline browsing
    * Ability to set HTTP Referers which allows to download files directly from
      webspace providers such as Lycos
    * Webpage itself appears in directory listing
    * Full history and Ctrl. Q support for Total Commander 5.51
    * Additional multilanguage support for Catalan, Polish, Hungarian, Danish,
      Norwegian and Italian


   Important note: When you upgrade your Total Commander 5.50 to 5.51 do not
   wonder when you can not see "Edit settings" anymore. You can reach the
   dialog by (right-click on "HTTP SmartBrowser" folder-properties).


   1.) INSTALLATION
   ================

   For installation you can either use the Installer which is available on our
   website and installs the plugin for you or do it manually:

   We recommend to use the filesystem plugin if you use Total Commander 5.50
   or newer! The packer plugin was mainly written for users which use old
   Windows Commander versions without filesystem plugin support.


   Installation (as filesystem plugin)
   ===================================
     * Copy "HTTPPlugin.dll" to your Total Commander directory
       (e.g. C:\Program Files\TotalCmd)
     * Copy "HTTPPluginXXX.lng" in Total Commander Language directory
       (e.g. C:\Program Files\TotalCmd\Language) and rename it to
       "HTTPPlugin.lng" (only necessary if want have the plugin in your
       own language and not in English)
     * Configuration -> Options -> Operations -> FS Plugins -> Add -> Enter
       "*.dll" to see all dll files of the current directory -> Choose
       "HTTPPlugin.dll" from your Total Commander directory

   You will now see "HTTP SmartBrowser" in "Network Neighborhood".

   Installation (as packer plugin)
   ===============================
     * Copy "HTTPPlugin.dll" to your Total Commander directory
       (e.g. C:\Program Files\TotalCmd)
     * Copy "HTTPPluginXXX.lng" in Total Commander Language directory
       (e.g. C:\Program Files\TotalCmd\Language) and rename it to
       "HTTPPlugin.lng" (only necessary if want have the plugin in your
       own language and not in English)
     * Configuration -> Options -> Packer -> Configure packer extensions DLLs
       -> Enter as file extension "http" -> New type -> Enter "*.dll" to see
       all dll files of the current directory -> Choose "HTTPPlugin.dll" from
       your Total Commander directory

   You can now access websites by opening the "virtual" http archives.
   Instead of the real file contents of the http file you will see all linked
   files from this website. The actual http file contains only the connection
   information with the following syntax ([]=optional):
   http://[Username:Password@]www.domain.com[:Port]/[Document]


   2.) FEATURE DESCRIPTIONS
   ========================

   Multi-Language support
   ======================
   If you want to have the plugin in your own language then copy your
   "HTTPPluginXXX.lng" file from the zip-archive (manual installation) to the
   Language directory of Total Commander and rename it to "HTTPPlugin.lng".
   Please do not forget to restart your Total Commander!
   If your language is missing and you want to make this plugin useable for
   everyone in your country by doing a translation then please send mail to:
   support@acd-group.com

   Password encryption
   ===================
   Password will be encrypted before they are saved in the IniFile.
   The plugin will append a "EncodedPwd(" and ")" at the beginning and the end
   of the encoded password. If you want to change your password then use the
   edit bookmarks dialog and replace the entire "EncodedPwd(...)" string with
   your new password. Nevertheless for security reasons we recommend not to save
   passwords!

   User defined IniFile location (requires TC 5.51 or newer)
   =========================================================
   Settings are saved in the shared "fsplugin.ini" (FS version)/"pkplugin.ini"
   (PA version) IniFile which is located in the same directory as your
   "TotalCmd.ini"/"WinCmd.ini".
   Note: If you use TC 5.50 or older then the IniFile needs to be located in
   the same directory as the HTTPPlugin.dll. The filenames of the IniFile must
   to be "wfx_http.ini" (FS version) / "wcx_http.ini" (PA version)

   Fully user configurable
   =======================
   The IniFile and the settings dialog (right-click on "HTTP SmartBrowser"
   (folder-properties) allows you to adapt the plugin to your needs. The
   following options are available:

   FollowLinkFileExtension=html;htm;php;php3;php4;phtm;phtml;asp
   ... = Only files with the specified extension will be followed...

   RetrieveFileInfoFileExtension=
   ... = retrieve file information (size & date) only from files with specified
         the extension
   (Note: The more extension you define the more bandwidth is needed...)

   RetriveFileInfoOnlyFromSameServer=
   ... = retrieve file information (size & date) only from files which are on
         the same server

   ShowAddNewBookmarkLnk=0 or 1
   0 = No "Add new bookmark" is shown in the root of "HTTP SmartBrowser"
   1 = "Add new bookmark" is shown in the root of "HTTP SmartBrowser" (default)

   ShowAddToBookmarksLnk=0 or 1
   0 = No "Add to bookmarks" is shown in the folders
   1 = "Add to bookmarks" is shown in the folders (default)

   ShowEditBookmarksLnk=0 or 1
   0 = No "Edit bookmarks" is shown in the root of "HTTP SmartBrowser"
   1 = "Edit bookmarks" is shown in the root of "HTTP SmartBrowser" (default)
   This option has been added because editing of bookmarks/settings this way
   is obsoleted (Right-click on file/folder-properties allows you to edit
   bookmarks and settings)

   ProxyServer=[username:password@]proxy.domain.com[:80]
   ... = Use the following syntax if your Proxyserver needs authentication:
   "username:password@proxy.domain.com" if not enter the server name only

   CacheWebsites=0 or 1
   0 = Directory listing will be loaded each time the folder is opened
   1 = Directory listing will be cached which allows faster go backs and
       forwards (default)
   You can clear the cache by deleting the folders appearing in the
   root dir of the plugin.

   ShowCurrentPageLnk=0 or 1
   0 = The current webpage name will not appear in the directory listing
   1 = The current webpage name will appear in the directory listing (default)

   StripSpecialCharsFromFileNames=0 or 1
   0 = No special chars will be stripped from file names (default)
   1 = Special chars will be stripped from file names
   This option has been added because there is a little bug in TC5.51 which
   prevents using the QuickView (Ctrl. Q) function in full. To use this
   function enable StripSpecialCharsFromFileNames

   StripSpecialCharsFromDirectoryNames=0 or 1
   0 = No special chars will be stripped from directory names (default)
   1 = Special chars will be stripped from directory names
   This option has been added because there is a little bug in TC5.51 which
   prevents using the History function in full. To use this function enable
   StripSpecialCharsFromDirecroryNames

   SetHTTPReferer=0 or 1
   0 = The "HTTPReferer" will left blank
   1 = The "HTTPReferer" will be set to the current webpage (default)
   This option has been added to allow users to download files directly from
   webspace providers such as Lycos


   3.) SUPPORT
   ===========

   support@acd-group.com
   http://www.ghisler.ch (Forum)


   4.) Credits
   ===========
   Thanks to Christian Ghisler, Fabio Chelly and his excellent ideas and the
   entire BetaTestingTeam:

      Christian Ghisler (Switzerland)
      Frank M�rtin (Germany)
      Fabio Chelly (France)
      Ajax (Russia)
      Leif Larsson (Sweden)
      Enrico Frumento (Italy)
      Tsunami Ulukai (Belgium)
      Panos (Greek)
      MaxWish (Netherlands)
      Stan (Russia)
      Petter Arild Heitman (Norway)
      Black Dog (Russia?)
      Dariusz J. Kawecki (Poland)
      Florian Heidenreich (Germany)

   and the translators:

      Tsunami Ulukai (French)
      Ajax (Russian)
      Enrico Frumento (Italian)
      Emiliano Llano D�az (Spanish)
      Joan Montan� (Catalan)
      Petter Arild Heitman (Norwegian)
      Leif Larsson (Swedish)
      Preben Kristensen (Danish)
      Janos Borus (Hungarian)
      Adrian Ulbrych (Polish)

   Enjoy the HTTP SmartBrowserPlugin!
   Andr� Martin (ACDGroup Ltd. - Dresden, GERMANY)


   5.) DONATIONS
   =============

   This is a non-commercial freeware product of the ACDGroup Ltd., Germany.
   If you like this plugin and you want to support the development of the
   plugin then we would be glad to hear from you - just send a mail to:
   donations@acd-group.com


   No Warranty
   ===========
   Because the program or document is licensed free of charge, there is no
   warranty for the program, to the extent permitted by applicable law. Except
   when otherwise stated in writing the copyright holders and/or other parties
   provide the program "as is" without warranty of any kind, either expressed
   or implied, including, but not limited to, the implied warranties of
   merchantability and fitness for a particular purpose. The entire risk as to
   the quality and performance of the program is with you. Should the program
   prove defective, you assume the cost of all necessary servicing, repair or
   correction.
   In no event unless required by applicable law or agreed to in writing will
   any copyright holder, or any other party who may modify and/or redistribute
   the program or document as permitted above, be liable to you for damages,
   including any general, special, incidental or consequential damages arising
   out of the use or inability to use the program or document (including but
   not limited to loss of data or data being rendered inaccurate or losses
   sustained by you or third parties or a failure of the program to operate
   with any other programs), even if such holder or other party has been
   advised of the possibility of such damages.
