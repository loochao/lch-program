Your vimrc will go here
Rename '.vimrc' or '_vimrc' to 'vimrc'!