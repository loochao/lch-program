wcpfrep32.wlx   Lister plugin for TotalCommander 
