Graphics Converter - Packer plugin for Total Commander

Converts files from most graphic formats to
BMP, GIF, JP2, JPG, PNG, TIFF (Uncompressed, LZW, Packbits, ZIP)

Image processing (currently) not supported.


Auto installation: (TC v6.5 or up)
~~~~~~~~~~~~~~~~~~
1. Enter or doubleclick on archive Graphics_Converter.rar
2. Follow installation instructions


Manual installation:
~~~~~~~~~~~~~~~~~~~~
1. Unpack archive Graphics_Converter.rar to any directory
2. In Total Commander select "Configuration|Options..."
3. Open the "Packer" page
4. Select "Configure packer extensions..."
5. Type in any unused extension (e.g. "Gra" or "GraCon").
   NOTE:
   Please don't use "GraphicsConverter" or any similar
   long extension - Total Commander doesn't support
   extensions longer than 15 characters.
6. Select "New", browse to the folder where you extracted
   GraphicsConverter.rar to and choose GraphicsConverter.wcx.
7. Press "OK"


Converting with the plugin:
~~~~~~~~~~~~~~~~~~~~~~~~~~~
The Plugin behaves like an archive type, just like any
other archiver in Total Commander.

1. Mark the image files or folders you want to convert
   as usually with Total Commander. You may select any
   non-image files as well - these will be skipped by
   Graphics Converter.
2. Select menu "Files|Pack...", shortcut (Alt+F5)
3. Select packer "Gra" or "GraCon"
4. In the "Pack files" dialog select "Configure...".
   The plugin doesn't need to be configured everytime,
   it will use the previous settings.
5. Choose a file format in "Graphics Converter settings" dialog
   (e.g. JPG). For several formats the quality/compression level
   and method can be selected.
6. Press "OK" to save settings
7. Additionaly you can use option "Recursively pack subdirectories".
8. Press "OK" to start the conversion process

   WARNING:
   Graphics Converter overwrites existing files without prompt!
   Coming in Graphics Converter v2.0 (see History.txt).


You can choose following languages:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 - Chinese_S by Cohan Liu
 - Danish    by Peter H. S. Madsen aka Petermad
 - French    by Motorocker :)
 - German    by deus-ex & TychoBarfy
 - Hungarian by Fabio
 - Polish    by ULTIMA-PRIME, http://www.tcup.pl
 - Russian   by Motorocker 
 - Swedish   by Leif Larsson
 - Spanish   by Nica Mlg
 - Spanish2  by Vico//Koby
 - Ukrainian by Maximus, http://maximus.in.ua/uation

Thank you, guys!

Please send me your translations or corrections.

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
� 2006-2007 Serga Plotnikov aka Motorocker
Web : motorocker.ru
Mail: zoth@bk.ru
ICQ : 235846782
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
You may post your comment on Graphics Converter here:

http://www.ghisler.ch/board/viewtopic.php?t=17771
http://totalcmd.net/plugring/graphics_converter.html
http://forum.wincmd.ru/viewtopic.php?p=18108
http://wincmd.ru/plugring/graphics_converter.html
