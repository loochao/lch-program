TorrentLister v0.01 by Christian Tiberg (ctiberg at home.se)

This plugin requires Total Commander v5.50 or later.

It lets you list the contents of Torrent files, including name, date, size and the files that are included.

This is released 'as-is', without any kind of warranty. It uses 

All source code is included, so you can just unpack src.zip and embedwb117_XP.zip and recompile it.
It uses units found on the internet, those are part of the "maketorrent project" and can be found at:

  http://krypt.dyndns.org:81/torrent/maketorrent/index.phtml
    
I also use an embedded browser:
  
  http://www.euromind.com/iedelphi/embeddedwb.htm 
  
Version history:
0.01	07/24/2005 Initial release
0.02	07/29/2005 Now uses TorrentLister_Template.html in plugins dir as an editable template for its output
  
Best of luck with the plugin :)