TTFViewer

Lister-plugin for TotalCommander

This plugin may be used for viewing TTF-files (TrueType Font) and OTF-files (OpenType Fonts)

Plugin has been tested with Win98SE, Win2000, WinXP, Win2003Server.

Current version is 0.1.2.4

Installation is standart

Plugin is free for using (freeware)

If you want to publish this plugin on your site, please, inform me by e-mail.

------------------------------------
Description:

There are 3 tabs: Sample, Glyph and Info, where text from pattern (file text.pat in the plugin-directory), glyphs-table and font-information are shown. You may choose charset for showing sample text and glyphs. Besides, samples may be shown in the thumbnail-mode (Total Commander 6.5 and higher).


1. Tab "Sample"

Text from the pattern is placed here. Text is showing with using current charset (it may be chosen in the combobox on the top of the plugin-window). There are some tags for editing pattern:

	<b>  - bold text;

	</b> - end of bold text;

	<i>  - italic text;

	</i> - end of italic text;

	<u>  - underlined text;

	</u> - end of underlined text;

	<hr> - separator;

	<size=12> - size of text (pt);

	<name=Arial> - text font name;

	<color=$FF00FF> - color of the text in the hexadecimal system ($BBGGRR B - Blue; G - Green; R - Red);

Following tags are useful for displaying some information about font file

        <currentfont> - name of the current font;
        <copyright>   - copyright string;
        <family>      - family name of the font;
        <subfamily>   - subfamily name of the font (tracing);
        <identifier>  - unique descriptor;
        <fullname>    - full name;
        <version>     - version of the file;
        <postscript>  - name for the Postscript;
        <trademark>   - trademark information.

It is possible to use this tags in constructions like '<name=<currentfont>>' or 'Copyright: <copyright>'.

All tags are not case sensitive. All tags (except <currentfont>, <copyright> etc.), must be placed on the separate line. If tag can't be recognized (for example, <i > or <size=1q> or <color=FFFFFF>), it's shown as text.

For editing pattern you may choose "Change Test Text"-item in the popup menu (right mouse button).

For installing font to the system choose item "Install Font" in this popup menu. In that case font file will be copied into the windows font-folder.



2. Tab "Glyph"

Table of the symbols with codes from $20 to $FF (or from 32 to 255) is placed here. Size of the symbols may be scalled by slider on the top of the window or table may be fitted into the window by the "Fit to window"-button. Charset may be changed too.

Popup-menu will help you to change the format of numeric codes (HEX or decimal), to select option "Auto fit to Window" or to copy symbol in the clipboard.



3. Tab "Info"

Depending on availability of information there may be found following information:

	Copyright notice
	Font Family name
	Font Subfamily Name
	Unique font identifier
	Full font name
	Version string
	Postscript name for the font
	Trademark

This information may be copied on the clipboard.

4. Thumbnails-mode

This feature is available in Total Commander version 6.5 or higher. In this mode 4 strings are shown: letters A-Z, symbols with codes from 192 to 223 (in my native land these symbols make up russian alphabet - I don't really know what do they mean in the other languages :-)), numbers and punctuation marks.

------------------------------------

What's new in version 0.1.2.4
+ copying char to clipboard;
+ support of the thumbnails-mode;
+ support of the OpenType-fonts with the .otf extension;
- fixed bug with the same appearance of the different style fonts


History:

0.1.2.3
- fixed bug with reading of read-only file;
- fixed bugs with the running plugin from CD-ROM etc.;
+ saving relative name of the language file in the ini-file;
+ refreshing of the text right after changing the pattern;
+ add tags
      <copyright>
      <family>
      <subfamily>
      <identifier>
      <fullname>
      <version>
      <postscript>
      <trademark>

0.1.2.2
* the structure of language file is changed for compatibility of subsequent versions with previous;
+ ability of reflection of characters' codes in a table in a decimal or hexadecimal format;
+ change of size of code signature with the change of scale;
+ change of scale for fit to window of table (only in width);
* changes in an interface;
- fixed several bugs.

0.1.2 beta:
+ choosing of different charsets;
+ switching of the tabs by keys Alt+Tab, Alt+Shift+Tab or Alt+PgDown, Alt+PageUp;
+ multilanguage interface (with russian and english languages in the archive);
- fixed several bugs.

0.1.1 beta
- fixed bugs from previous version;
+ multitab interface;
+ file information;
+ separate glyphs;
+ scalling symbols in glyphs;
+ ini-file.

------------------------------------



Author: Pankratiev Alexey, aka Murashka
E-mail: koe_kto@pochta.ru

� 2004 Murashka
