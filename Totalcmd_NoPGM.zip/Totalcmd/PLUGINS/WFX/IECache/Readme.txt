"MSIE Cache Browser" plugin for Total Commander
-----------------------------------------------
This file-system plugin allows to browse Microsoft Internet Explorer
cache ("Temporary Internet Files" folder contents). Unlike Explorer,
plugin shows cache in structured form: domains list, sites list for
every domain, URLs list for every site.

Notes:
- Cache entries can be opened and deleted. Opening of an entry will
  open it in MSIE in offline mode;
- To reread cache open "Reread cache" pseudo-file.


Installation
------------
With TC 6.5+: just open archive and TC will install plugin automatically.
Or - installation by hand: unpack archive to some folder and install like
any other FS plugin: go to Options -> Plugins -> File-system plugins ->
Add, then select IECache.wfx file.


Versions history
----------------
29.04.06: Delphi source code released;
          calling of options dialog now doesn't start cache re-read

19.02.06: fixed too big memory usage;
          fixed focus loosing of read-progress indicator

22.10.05: changing of language updates Options window text
19.10.05: added configuration dialog (press Alt+Enter on plugin name)
          and cache read-progress indicator;
          entries dates are now displayed

11.10.05: added IECache.lng language file;
          added IECache.ini file with options:
            Language: set language,
            ShowCookies: set visibility of Cookies,
            OfflineOpen: set offline mode on URL opening,
            OfflineStart: set offline mode on plugin start,
            ConfirmOpen: set confirmation on URL opening,
            SkipDomains: set skipping of 2nd-level domains;
          fixed files search;
          fixed panel rereading;
          added "MSIE version" string to plugin properties messagebox

07.10.05: improved cache read speed
06.10.05: initial version


Copyright (c) 2006 Alexey Torgashin <atorg@yandex.ru>
http://atorg.net.ru
http://totalcmd.net/plugring/msie_cache.html
