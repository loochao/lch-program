These software are provided "as-is". No warranty provided.
You use this program at your own risk. The author will not 
response for data loss, damages, etc. while using or misusing 
this software.


This plugin is freeware.


Current User Privileges - plugin for Total Commander 5.5 and newer.

Features:
  - Allow uninstall useless programs right from TC panel
    by pressing "Enter" key (mouse click).

Test works only in 2k/XP.

Version history:
---------------------
v 1.01 - 27.11.2002
  - Fix one bug.


v 1.0 - 17.11.2002
  - Initial version



Author:
  LittleLuffi (Russia)
  email: luffi@land.ru
    WWW: http://luffi.by.ru
