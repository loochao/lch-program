////////////////////////////////////////////////////////////////////////////
// fhRAR.wcx : RAR Plugin for Total Commander.
//
// Copyright (C) 2005 Flying Horse Productions, LLC
// Address: Flying Horse Productions, LLC
//          Software Support
//          3392 Peachtree Road NW
//          Duluth, GA 30096-3205 USA
// Website: http://www.flying-horses.com
// E-mail : support@flying-horses.com
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License, version 2 as
// published June 1991, by the Free Software Foundation.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the
// Free Software Foundation, Inc.
// 51 Franklin St, Fifth Floor
// Boston, MA  02110-1301  USA
////////////////////////////////////////////////////////////////////////////

0. About
--------
The fhRAR plugin was created with one simple purpose in mind:
The ability to view and extract entire multi-volume RAR archive sets from
within Total Commander.

At this stage the fhRAR plugin merely acts as an interface between
Total Commander and unrar.dll.

(A more recent version of unrar.dll is included if you wish to replace the
one that is distributed with your version of Total Commander. As of TC
version 6.53, the unrar.dll included with this plugin is more recent and
contains minor fixes for bugs that were discovered during the development
of this plugin.)-  Temporary removed by Lamer.

1. Installation
---------------
As of Total Commander version 6.5 simply opening the archive containing the
files for this plugin should allow automated installation. For further
details please refer to the Total Commander documentation.

2. Caveats
----------
1.) This plugin may not be fully compatible with RAR archive versions
earlier than 3.0.

2.) The fhRAR plugin is capable of handling RAR archives that have encrypted
headers (the type of password protection that hides the archive contents).

***BE FOREWARNED*** Total Commander caches archive listings for a
particular tab until a new archive is opened, or until TC is closed. When
working with these types of archives within TC it is possible to list the
archive contents even though the archive has been exited. This of course
defeats the purpose of encrypting RAR archive headers and may pose a
SECURITY RISK. It is recommended that after working with these types of
archives that the user close the Total Commander program to flush this
cache or use alternate means to work with RAR archives that have encrypted
headers.


3. Features
-----------
 + Full multi-volume support
 + Archive listing
 + Archive extraction
 + Archive CRC testing
 + Handles encrypted archive headers
 + Handles encrypted files


4.
0.1.0: 2005.07.27
 + Initial Public Release

0.2.0: 2006.11.15
 + Cirillic support added by Lamer
 
0.2.1: 2006.11.20
 + Partial unicode support added by Lamer

0.2.2: 2006.11.23
 + Bug with unpacking Rar archives from *nix systems fixed by Lamer
 
0.2.3: 2006.05.21 
 + Added WCX plugin interface 2.12 support (ReadHeaderEx) -> Indicates packed file size more than 4GB with TC7 right. (by Lamer)
 
At this stage plugin ver 0.2.3 is TC6.xx and TC7RC4 compatible.(Lamer) 