Age 1.00 BETA 1
---------------

Age is a content plug-in for Total Commander. 


Contents
--------

  1. Plug-in description
  2. Fiekd descriptions
  3. System requirements
  4. Use
  5. Version history
  6. Author contact
  7. License and liability


1. Plug-in description
---------------------- 

Age can be used to search for files where the file age is roughly known. The normal search (extended tab) can be used to find files not older than a certain time span. That's fine but insufficient for many tasks. You can't find files older than a certain time span this way.


2. Field descriptions
---------------------

Changed    	Point of time where the file has been changed lastly relative to the current time.
Created    	Point of time where the file has been created relative to the current time.
Accessed 	Point of time where the file has been accessed lastly relative to the current time.   


3. System requirements
----------------------

For this plug-in Total Commander 6.50 is required.


4. Use
------

This plug-in can be used in all program parts where content plug-ins are supported. However it's mainly thought to be used for the search. Below you'll find some examples how to use this plug-in. 


4.1 Operators
-------------
 
Operator   	Sense
--------	-----

>   		older than
<   		newer than
>=   		at least as old or older than
<=   		as most as old or newer than
=   		as old
!=              older or newer

The operators are always referring to complete time units. What that means for the search is explained in the example below.
 

4.2 Example:
------------

The current date is June 22, 2006. The files with the following dates are given:
--------------------------------------------------------------------------------

February 21, 2006
February 22, 2006
February 23, 2006
March 21, 2006
March 22, 2006
March 23, 2006
April 21, 2006
April 22, 2006
April 23, 2006


The rule "age < 3 months" will give the following result:
---------------------------------------------------------

March 23, 2006
April 21, 2006
April 22, 2006
April 23, 2006

Comment: March 22 is exactly 3 months ago
 

The rule "age <= 3 months" will give the following result:
----------------------------------------------------------

February 23, 2006
March 21, 2006
March 22, 2006
March 23, 2006
April 21, 2006
April 22, 2006
April 23, 2006

Comment: February 22 is exactly 4 months ago. That means this file doesn't fulfill the condition newer or as old as.

The rule "age > 3 months" will give the following reuslt:
---------------------------------------------------------

February 21, 2006
February 22, 2006
 
Comment: These two days in February are 4 months ago. That means they are older then 3 months.


The rule "age >= 3 months" will give the following reuslt:
----------------------------------------------------------

February 21, 2006
February 22, 2006
February 23, 2006
March 21, 2006
March 22, 2006

Comment: Here all files are found which are 3 months old or older.


5. Version history
------------------

Version 1.00   First release.


6. Author contact
-----------------

There is a thread in the {Total Commander forum} which can be used to discuss problems, bug and suggestions:
http://www.ghisler.ch/board/viewtopic.php?t=11292


7. License and liability
------------------------

Age copyright � 2006 Christian Hillbricht. Any liability for damage of any sort is hereby denied. All rights reserved. This Total Commander plug-in is copyrighted freeware.