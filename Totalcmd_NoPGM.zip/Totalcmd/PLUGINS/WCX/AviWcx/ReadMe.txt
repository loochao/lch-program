----- AVIWCX - AVI Extension plugin for Total Commander -----

Version 1.7


Reads and Writes "Video For Windows" AVI files.


1. Installation

- unzip the aviwcx.wcx to your Total Commander installation directory
- choose the menu configuration - options
- choose the packer tab
- click the configure packer extension dlls button
- type avi as new extension
- click new type, and select aviwcx.wcx
- click ok
- select an *.avi file and press CTRL+PAGEDOWN to browse the file and extract frames
- select a set of bitmap files and press Alt+F5. Select avi (click on configure) and start to encode a video



2. Extracting

Enter a AVI file by pressing CTRL+PAGEDOWN
- Directories named by the image type of the images it offers. i.e. the directory bmp contains all frames of the video in bmp image format. CURRENTLY ONLY BMP IS AVAILABLE.
- If the video contains an audio stream, it is represented as 'audio.wav'. You may extract it.
- The whole video is represented as 'video.avi' itself. Try to extract it, and you will be asked for a new video codec. With that feature you can "reencode" the video.
- The 'Info.txt' file contains information about the video file and the format.
- Only frames bwloe the 2 GB barrier can be extracted!
- The decoding quality may depend on your current display bit depth. 



3. Encoding

You can select a bunch of images stored on your harddrive and pack it into an AVI video file.
- All images are stretched to the dimensions of the first image file.
- All images are set to the bit depth of the first image file. If it is 8 bpp, the color palette of the first image is assigned. Be aware of, that only few codecs accept 8 bit images, to the encoding may fail. The first image should have a palette, which is suiteable for all images. 
- When starting to encode, the compression options dialog is shown up.
- You can include a wave file as the first audio stream of the video. The wave file should have the same length as the video stream. In my opinion, encoding works better without audio. 
- Encoding up to the 2 GB barrier works fine. 
- All the files are added in the order, you have selected them in the almighty Total Commander (from top to bottom). By changing the sort order in TC, the order in the video changes.
- The losslessness of your created video file depends in the avi compressor. Typically there is a loss of quality. You most likely won't be able to extract the images the same quality, they were added.
- The encoding framerate can be modified in the packer extension configuration dialog (Click on configure in the compression dialog, below where you can select the avi plugin).



4. Misc

- Modifying of existing AVI files is not supported. You can neither add nor delete frames of exising files. If you want to modify a file, you have to extract the whole file, modify the files, and encode them again.
- These image formats are supported for encoding:
  o bmp
  o jpg
  o pcx
  o png (without alpha, of course)
  o tga
  o tif



5. Contact

You will find this plugin on the Total Commanders website: http://www.ghisler.com

My email: Dr.Algebra@gmx.de
My homepage: www.sascha.hlusiak.de


This plugin contains a lot of code of the CxImage Library, for handling all the gfx-formats.
Visit http://www.codeproject.com/bitmap/cximage.asp for more information.



--------------------------------


NOTE: This plugin is freeware for private use. Companies, who use this plugin commercially, may please inform me first.  



Thank you for trying my plugin. =)


This plugin was created by Sascha Hlusiak (December, 2003).











42