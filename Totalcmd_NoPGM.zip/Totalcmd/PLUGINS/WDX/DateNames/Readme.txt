DateNames 1.00 BETA 3
---------------------

DateNames is a content plug-in for Total Commander.


Description
-----------

DateNames provides the names of months and days of week of file dates. The three file dates creation date, write date and access date are supported.


Field descriptions
------------------

DateNames provides the following fields:

Month (Creation Date)		Month in which the file has been created.
Month (Write Date)		Month in which the file has been modified lastly.
Month (Access Date)		Month in which the has been accesses lastly.
Day of Week (Creation Date)	Month in which the file has been created.
Day of Week (Write Date)	Month in which the file has been modified lastly.
Day of Week (Access Date)	Month in which the has been accesses lastly.


System requirements
-------------------

Total Commander 6.50 is required for this plug-in. All 32 bit Windows versions ((95/98/ME/2000/XP/2003) are supported.


License and liability
---------------------

DateNames copyright � 2006 Christian Hillbricht. 
Any liability for damage of any sort is hereby denied. All rights reserved. This Total Commander plug-in is copyrighted freeware.