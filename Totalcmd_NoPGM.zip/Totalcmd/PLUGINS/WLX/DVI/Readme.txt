DVI Simple Viewer plugin 1.0.0.1 for Total Commander
====================================================

 * License:
-----------

This software is released as freeware.


 * Disclaimer:
--------------

This software is provided "AS IS" without any warranty, either expressed or
implied, including, but not limited to, the implied warranties of
merchantability and fitness for a particular purpose. The author will not be
liable for any special, incidental, consequential or indirect damages due to
loss of data or any other reason.


 * Installation:
----------------

 1. Unzip the archive to an empty directory
 2. In Total Commander choose "Configuration => Options"
 3. Choose "Edit/View"
 4. Click "Configure internal viewer..."
 5. Click "LS-Plugins"
 6. Click "Add" and select dvi.wlx
 7. Click "OK" twice


 * Description:
---------------

The DVI Simple Viewer plugin displays device independent TEX output in the
lister window of Total Commander.


 * ChangeLog:
-------------

 o Version 1.0.0.1 (16.03.2006)
   - first public version


 * References:
--------------

 o LS-Plugin Writer's Guide by Christian Ghisler
   - http://ghisler.fileburst.com/lsplugins/listplughelp1.5.zip
 o WinDvi SDK Version 1.0 by Impress Corporation
   - http://home.impress.co.jp/download/wdvisdk/WDSDK10.EXE


 * Trademark and Copyright Statements:
--------------------------------------

 o Total Commander is Copyright � 1993-2006 by Christian Ghisler, C. Ghisler & Co.
   - http://www.ghisler.com
 o UPX - The Ultimate Packer for eXecutables is Copyright � 1996-2006 by Markus
   Oberhumer & Laszlo Molnar.
   - http://upx.sourceforge.net
 o WinDvi SDK Version 1.0 is Copyright � 1996 by Impress Corporation, Japan.
   - http://home.impress.co.jp/aftercare/wintex/wdvisdk


 * Feedback:
------------

If you have problems, questions, suggestions please contact Thomas Beutlich.
 o Email: support@tbeu.de
 o URL: http://tbeu.totalcmd.net