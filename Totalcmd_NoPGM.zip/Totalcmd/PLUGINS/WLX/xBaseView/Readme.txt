xBaseViewFree.wlx - xBaseView Database Explorer Lite
Version 7.3 Build 0719 (April 12, 2007)

xBaseView Database Explorer Lite is a Total Commander plug-in with the interface resembling Windows Explorer. xBaseViewFree supports all typical database operations, including database viewing, editing, printing, searching, querying, import and export, including conversion to a different database format.

File extensions and Database types
- .CDS	Borland Client Data Set
- .CSV	CSV Text
- .DB  	Paradox
- .DBF	Clipper
- .DBF	dBase
- .DBF	FoxPro
- .HTM	HTML Text
- .HTML	HTML Text
- .TAB	TAB Text
- .XML	Borland Data Packet XML
- .XML	Microsoft ADO XML

xBaseView requires database drivers in order to open database files and execute SQL queries.

Main distribution packages (free downloads)
- MDAC (Microsoft Data Access Components) 2.1 or above
- Microsoft OLE DB Provider for Visual FoxPro
- BDE (Borland Database Engine) 5.0 or above

Drivers required to open the following database formats
- CSV  Microsoft Jet OLE DB 4.0 Provider
- DB   BDE Driver
- HTM  Microsoft Jet OLE DB 4.0 Provider
- TAB  Microsoft Jet OLE DB 4.0 Provider
- XML  Microsoft Jet OLE DB 4.0 Provider

Drivers required to execute SQL statements
- Paradox DB  BDE Driver
- dBase  DBF  BDE Driver
- FoxPro DBF  VFP OLE DB Provider or VFP ODBC Driver

Download Database Drivers (as of March, 2007)
- Microsoft Data Access Components (MDAC) 2.8 SP1 (5.8 MB)
  http://www.microsoft.com/downloads/details.aspx?familyid=78CAC895-EFC2-4F8E-A9E0-3A1AFBD5922E&displaylang=en
- Microsoft OLE DB Provider for Visual FoxPro version 9.0 (2.5 MB)
  http://www.microsoft.com/downloads/details.aspx?FamilyId=E1A87D8F-2D58-491F-A0FA-95A3289C5FD4&displaylang=en
- Borland Database Engine 5.2 MSI Merge Module Enterprise (9.7 MB)
  http://info.borland.com/devsupport/bde/bdeupdate.html

Many thanks to:
    - Andrey Pyasetskiy for the Totalcmd.net
    - Christian Ghisler for the Total Commander
    - Nullsoft Incorporated for the NSIS Installer
    - Troy Wolbrink for the Tnt Unicode Controls
  for the translations into foreign languages:
    - Bulgarian:  Georgi Krushkov
    - Croatian:   Davor Bokun, Trpimir Blazevic
    - Czech:      Marek Soucek
    - Dutch:      Erwin Veermans
    - French:     Franck Gartemann, Claude Charries
    - German:     Alexander Katassonov, Dieter Rehfeld
    - Greek:      Dimitrios Valsamis
    - Italian:    Pierluigi Montinaro, Diamanti
    - Polish:     Bogdan Wozniak
    - Romanian:   Nostriel
    - Spanish:    Luis Mejia, Martin Rissoto
    - Ukrainian:  Maximus, Serhiy Dubyk
  for the algorithms and advices:
    - Alexey Torgashin aka Alextp
    - Georgi Krushkov aka Krusheto
    - Kulikov Alexey aka Alexey
    - Mike Gavrilov aka NTMan
    - Roman Novosostavskiy aka StayAtHome
    - Sergey Puskin aka Serge
    - Sergey Rogozhnikov aka SR
    - Valery Kurenkov aka Akulabig

Copyright � 2004-2007 Mutex LLC.
www.xbaseview.com
